/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1_verifica;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
* @author orsenigo_andrea 
* 
* @class Cane.java
* 
* @brief Simula l'allenamento di un cane (partenza e presa del manichino)
*   Collabora con la classe DatiCondivisi
* 
*/
public class Cane extends Thread{
    private DatiCondivisi dc;
    /** intero che indica il numero del cane **/
    private int num;
    
    public Cane(DatiCondivisi dc, int n){
        this.dc = dc;
        num = n;
    }
    
    @Override
    public void run(){
        Random r = new Random();
        dc.WaitSemLanciato(num);
        System.out.println("cane " + num + " PARTITO");
        float attesa = r.nextFloat() + 1;
        System.out.println("...cane " + num + " ATTESA DI " + attesa + " SECONDI");
        try{
            Thread.sleep((long)attesa*1000);
        }catch(InterruptedException ex){
            Logger.getLogger(Cane.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("cane " + num + " PRENDE manichino " + num);
        dc.SignalSemPreso(num);
    }
}
