/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1_verifica;

/**
* @author orsenigo_andrea 
* 
* @class DatiCondivisi.java
* 
* @brief Classe che contiene i dati condivisi tra i threads
*   Collabora con la classe Semaforo
* 
*/
public class DatiCondivisi {
    private Semaforo semLanciato1;
    private Semaforo semLanciato2;
    private Semaforo semPreso1;
    private Semaforo semPreso2;
    
    /**
     * @brief costruttore senza parametri che inizializza i semafori a 0
     */
    public DatiCondivisi(){
        semLanciato1 = new Semaforo(0);
        semLanciato2 = new Semaforo(0);
        semPreso1 = new Semaforo(0);
        semPreso2 = new Semaforo(0);
    }
    
    /**
     * @brief Richiama il metodo wait sul semaforo richiesto
     * 
     * @param n intero che può assumere valore 1 o 2 e che segnala di quale semaforo richiamare la wait
     */
    public void WaitSemLanciato(int n){
        if(n==1)
            semLanciato1.Wait();
        else
            semLanciato2.Wait();
    }
    
    /**
     * @brief Richiama il metodo signal sul semaforo richiesto
     * 
     * @param n intero che può assumere valore 1 o 2 e che segnala di quale semaforo richiamare la signal
     */
    public void SignalSemLanciato(int n){
        if(n==1)
            semLanciato1.Signal();
        else
            semLanciato2.Signal();
    }
    
    /**
     * @brief Richiama il metodo wait sul semaforo richiesto
     * 
     * @param n intero che può assumere valore 1 o 2 e che segnala di quale semaforo richiamare la wait
     */
    public void WaitSemPreso(int n){
        if(n==1)
            semPreso1.Wait();
        else
            semPreso2.Wait();
    }
    
    /**
     * @brief Richiama il metodo signal sul semaforo richiesto
     * 
     * @param n intero che può assumere valore 1 o 2 e che segnala di quale semaforo richiamare la signal
     */
    public void SignalSemPreso(int n){
        if(n==1)
            semPreso1.Signal();
        else
            semPreso2.Signal();
    }
}
