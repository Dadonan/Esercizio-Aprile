/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1_verifica;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Random;

/**
* @author orsenigo_andrea 
* 
* @class Manichino.java
* 
* @brief Simula il lancio e il salvataggio di un manichino
*   Collabora con la classe DatiCondivisi
* 
*/
public class Manichino extends Thread{
    private DatiCondivisi dc;
    /** intero che indica il numero del manichino **/
    private int num;
    
    public Manichino(DatiCondivisi dc, int n){
        this.dc = dc;
        num = n;
    }
    
    @Override
    public void run(){
        Random r = new Random();
        System.out.println("manichino " + num + " LANCIATO");
        dc.SignalSemLanciato(num);
        dc.WaitSemPreso(num);
        System.out.println("manichino " + num + " INIZIO SALVATAGGIO");
        float attesa = r.nextFloat() + 1;
        System.out.println("...manichino " + num + " ATTESA DI " + attesa + " SECONDI");
        try{
            Thread.sleep((long)attesa*1000);
        }catch(InterruptedException ex){
            Logger.getLogger(Manichino.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("manichino " + num + " FINE SALVATAGGIO");
    }
}
