/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1_verifica;

import java.util.Scanner;

/**
 *
 * @author orsenigo_andrea
 * 
 * @class Es1_verifica
 * 
 * @brief Main
 *  Collabora con la classe DatiCondivisi, Cane e Manichino
 */
public class Es1_verifica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Scanner input = new Scanner(System.in);       
        String str;
        boolean finito = false;
        while(!finito){
            System.out.println("PREMI s PER FAR LANCIARE 2 MANICHINI E LIBERARE I 2 CANI O f PER FINIRE");
            str = input.nextLine();
            if(str.equals("s")){
                DatiCondivisi datiCon = new DatiCondivisi();
                Cane c1 = new Cane(datiCon, 1);
                Cane c2 = new Cane(datiCon, 2);
                Manichino m1 = new Manichino(datiCon, 1);
                Manichino m2 = new Manichino(datiCon, 2);
                c1.start();
                c2.start();
                m1.start();
                m2.start();
                c1.join();
                c2.join();
                m1.join();
                m2.join();
                System.out.println("MANICHINI SALVATI");
            }
            else if(str.equals("f"))
                finito = true;
        }
    }  
}
