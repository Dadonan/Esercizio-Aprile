/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1_verifica;

/**
* @author orsenigo_andrea 
* 
* @class Semaforo.java
* 
* @brief Implementazione Semaforo
* 
*/
public class Semaforo {
    /** contatore del semaforo **/
    int valore;

    /**
     * @brief costruttore con parametro che inizializza il contatore del semaforo
     * 
     * @param n intero che rappresenta il valore con cui inizializzare il semaforo 
     */
    public Semaforo(int n) {
        valore = n;
    }

    synchronized public void Wait() {
        while (valore == 0) {            
            try {
                wait();
            } 
            catch (InterruptedException e) {
            }
        }
        valore--;                          
    } 
    synchronized public void Signal() {
        valore++;                          
        notify();                          
    }
}
